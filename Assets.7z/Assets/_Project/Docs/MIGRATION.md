# Migration (from older projects)
- Import CODE first (Runtime, then Editor)
- Avoid dragging old `ProjectSettings/` or `Library/`
- Bring content *selectively* (models, textures, audio)
- Recreate scenes in the new layout; drop prefabs back in