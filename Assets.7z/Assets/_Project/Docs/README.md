# Wild Survival — Project Docs (Foundation)
Keep these short, current, and actionable.

- **STRUCTURE.md**: what lives where
- **WORKFLOW.md**: daily dev + branching
- **SCENES.md**: scene roles & load order
- **MIGRATION.md**: selective import rules
- **ASSETS_TREE.txt**: export via the wizard