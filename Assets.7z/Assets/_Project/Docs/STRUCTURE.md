# Structure (clean base)
```
Assets
 ├─ _Project
 │   ├─ Code
 │   │   ├─ Runtime
 │   │   └─ Editor
 │   ├─ Docs
 │   ├─ Prefabs
 │   ├─ Scenes
 │   └─ Settings
 └─ WildSurvival
     ├─ Runtime
     ├─ Editor
     └─ Content
```