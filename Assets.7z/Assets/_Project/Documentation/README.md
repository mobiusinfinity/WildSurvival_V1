# Wild Survival

## Project Structure
- **_Project**: Main project files
- **_DevTools**: Development tools
- **_ThirdParty**: External packages
- **_Tests**: Unit tests

## Quick Start
1. Open _Bootstrap scene
2. Press Play

## Systems
- Inventory System
- Crafting System
- Vitals System

Generated: 2025-08-11